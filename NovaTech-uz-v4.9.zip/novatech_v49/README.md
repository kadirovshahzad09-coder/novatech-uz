# NovaTech-uz v4.3 — lokal sinov

## Ishga tushirish
Python 3.10+ kerak. Kutubxonalarni o‘rnating:

```bash
python -m pip install -r requirements.txt
```

macOS/Linux:
```bash
export NOVATECH_ADMIN_USER='admin'
export NOVATECH_ADMIN_PASSWORD='OzingizTanlaganKuchliParol'
python3 server.py
```

Windows PowerShell:
```powershell
$env:NOVATECH_ADMIN_USER='admin'
$env:NOVATECH_ADMIN_PASSWORD='OzingizTanlaganKuchliParol'
python server.py
```

Brauzerda `http://127.0.0.1:8000` oching, Admin bo‘limida kiring.

## v4.3 yangiliklari
- Admin ombor jadvalidagi **Etiketka** tugmasi 50×30 mm chop etiladigan etiketka yaratadi.
- Etiketkada mahsulot nomi, SKU, narx, haqiqiy QR va Code 128 shtrix kod mavjud.
- QR ichida NovaTech-uz nomi va SKU bor. Bu hozircha mahsulotning internet manzili emas.
- QR va shtrix kod serverda hosil qilinadi, brauzer printer dialogini ochadi.
- Termoprinterda 50×30 mm qog‘oz, 100% masshtab va 0 mm marginni sozlang. Printer drayveri kompyuterda o‘rnatilgan bo‘lishi kerak.
- SKU Code128 uchun ASCII belgilaridan iborat bo‘lishi kerak.

## Cheklovlar
Lokal prototip, internetga bevosita ochmang. Brauzer orqali chop etish printer drayveriga bog‘liq; barcha termoprinterlarda tekshirilmagan. Telegram integratsiyasi, haqiqiy serverga joylash, HTTPS, zaxira nusxa avtomatizatsiyasi va sessiyalarni doimiy saqlash hali mavjud emas. Oldingi `admin-v3.html` mustaqil demo.

Baza: `novatech.sqlite3` — uni muntazam zaxiralang.

## v4.4 — Telegram buyurtmalari
- Mijoz katalogda RAM/SSD tanlab **Buyurtma berish** tugmasini bosadi.
- Server tanlovlar va narxni bazadagi variantlar bo‘yicha mustaqil tekshiradi, buyurtmani `orders` jadvaliga saqlaydi.
- Admin panelda **Yangi buyurtmalar** ko‘rinadi. Buyurtma ombor qoldig‘ini kamaytirmaydi: sotuv alohida tasdiqlanadi.
- Telegram bot orqali bildirishnoma yuborish uchun bot token va chat ID ni server ishga tushishidan oldin muhitga kiriting:
  - `NOVATECH_TELEGRAM_BOT_TOKEN` — BotFather bergan token
  - `NOVATECH_TELEGRAM_CHAT_ID` — do‘kon xabarlari boradigan chat ID
- Bot tegishli chatga qo‘shilgan va yozish huquqiga ega bo‘lishi kerak. Tokenni HTML/JavaScript ichiga qo‘ymang va hech kimga oshkor qilmang.
- Token yoki chat ID bo‘lmasa ham buyurtma bazaga saqlanadi, ammo Telegram xabari yuborilmaydi. Admin panelda holat ko‘rsatiladi.
- Buyurtma hali to‘lov emas; xaridor bilan bog‘lanish va yakuniy tasdiqlash uchun qo‘shimcha jarayon talab qilinadi. Mijoz telefon raqami yig‘ilmaydi.
- Ochiq internetga chiqarishdan oldin HTTPS, login rate-limit, CSRF/CORS strategiyasi, botga bildirishnoma retry, spamga qarshi cheklov va zaxiralash kerak.

## v4.5 — Shaxsiy Telegramga buyurtma
- Buyurtma server bazasiga saqlangach, `https://t.me/KalarovKH` ochiladi.
- Buyurtma tafsilotlari clipboardga nusxalanadi; mijoz chatga joylab **Yuborish**ni bosadi.
- Telegram shaxsiy akkauntiga avtomatik xabar yuborish imkoni yo‘q: bu usul foydalanuvchi tasdig‘ini talab qiladi.
- Brauzer popup yoki clipboard ruxsatini bloklasa, buyurtma matni ko‘rsatiladi.
- Backenddagi avvalgi ixtiyoriy bot integratsiyasi saqlangan, lekin bu oqimda bot talab qilinmaydi.

## v4.6 — Buyurtmalarni boshqarish
Admin panelda yangi buyurtmani tasdiqlash yoki bekor qilish, tasdiqlangan buyurtmani sotuvga aylantirish mumkin. Sotuvga aylantirish omborni kamaytiradi, savdoni va ombor harakatini atomik tranzaksiyada yozadi. Takroriy sotuv rad etiladi. Migratsiya mavjud orders jadvaliga sale_id ustunini qo‘shadi. Avvalgi bazangizni zaxiralang. Bu lokal prototip bo‘lib, internetga ochish uchun qo‘shimcha xavfsizlik kerak.


## v4.7 hisobotlar
`GET /api/reports` faqat admin tokeni bilan ishlaydi. Kunlik (30 kun), oylik (12 oy), eng ko‘p sotilganlar, ombor va buyurtma holatlari qaytadi. Hisobot tushum bo‘yicha, sof foyda emas. Telegram @KalarovKH mijoz tomonidan qo‘lda yuboriladigan tayyor xabar orqali ishlaydi.


## v4.8 — tannarx va xarajatlar
Mahsulot tannarxi ixtiyoriy. Sotuv vaqtida tannarx nusxasi savdoga saqlanadi (keyingi narx o‘zgarishi tarixiy foydani o‘zgartirmaydi). Eski savdolarda tannarx noma’lum qoladi; ular uchun sof natija ko‘rsatilmaydi. Xarajatlar USDda kiritiladi. Bu soddalashtirilgan hisob: soliqlar, qaytarishlar, kurs farqlari, chegirmalar va pul oqimi alohida yuritilmaydi.

## v4.9 — qarzdorlik
Admin uchun `/api/debts` va `/api/debt-payments` endpointlari qo‘shildi. Mijozlardan olinadigan va do‘kon to‘lashi kerak bo‘lgan qarzlar, qisman to‘lovlar, muddat va qolgan summa saqlanadi. Qoldiqdan ortiq to‘lov bloklanadi. Muddati o‘tgan qarzlar admin panelda ko‘rsatiladi, lekin Telegramga avtomatik eslatma yuborilmaydi. Qarz yozuvlari savdo hisobotiga avtomatik kiritilmaydi. Zaxira nusxasini muntazam oling.
